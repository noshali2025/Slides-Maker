import type { Template } from "@shared/schema";

export const TEMPLATE_DATA: Omit<Template, 'id' | 'createdAt'>[] = [
  // SLIDE TEMPLATES (5)
  {
    name: "Modern Pitch Deck",
    category: "slide",
    description: "Clean and professional presentation template for business pitches",
    thumbnail: null,
    content: {
      title: "Your Company Name",
      subtitle: "Innovative Solutions for Modern Business",
      content: "Elevate your presentation with our modern design. Perfect for startups and enterprises.",
      backgroundColor: "#F8FAFC",
      textColor: "#1E293B",
      accentColor: "#8B5CF6"
    }
  },
  {
    name: "Dark Theme Slide",
    category: "slide",
    description: "Elegant dark theme perfect for tech presentations",
    thumbnail: null,
    content: {
      title: "Dark Innovation",
      subtitle: "Technology & Future",
      content: "Embrace the power of dark design for your next presentation.",
      backgroundColor: "#0F172A",
      textColor: "#F1F5F9",
      accentColor: "#F43F5E"
    }
  },
  {
    name: "Gradient Vision",
    category: "slide",
    description: "Vibrant gradient backgrounds for creative presentations",
    thumbnail: null,
    content: {
      title: "Creative Vision",
      subtitle: "Design & Innovation",
      content: "Stand out with stunning gradient designs that capture attention.",
      backgroundColor: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      textColor: "#FFFFFF",
      accentColor: "#FCD34D"
    }
  },
  {
    name: "Minimalist Slide",
    category: "slide",
    description: "Clean minimalist design for focused content",
    thumbnail: null,
    content: {
      title: "Less is More",
      subtitle: "Minimalist Design Approach",
      content: "Focus on what matters with our clean minimalist template.",
      backgroundColor: "#FFFFFF",
      textColor: "#0F172A",
      accentColor: "#10B981"
    }
  },
  {
    name: "Corporate Blue",
    category: "slide",
    description: "Professional corporate template in blue tones",
    thumbnail: null,
    content: {
      title: "Corporate Excellence",
      subtitle: "Professional Business Solutions",
      content: "Trust and professionalism in every slide.",
      backgroundColor: "#EFF6FF",
      textColor: "#1E3A8A",
      accentColor: "#3B82F6"
    }
  },

  // INVOICE TEMPLATES (5)
  {
    name: "Professional Invoice",
    category: "invoice",
    description: "Clean and professional invoice template",
    thumbnail: null,
    content: {
      companyName: "Your Company Name",
      companyAddress: "123 Business Street, City, State 12345",
      companyEmail: "contact@company.com",
      companyPhone: "+1 (555) 123-4567",
      clientName: "Client Name",
      clientAddress: "456 Client Avenue, City, State 67890",
      invoiceNumber: "INV-001",
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Service/Product 1", quantity: 1, rate: 100, amount: 100 },
        { description: "Service/Product 2", quantity: 2, rate: 50, amount: 100 }
      ],
      subtotal: 200,
      tax: 20,
      total: 220,
      notes: "Thank you for your business!"
    }
  },
  {
    name: "Modern Invoice",
    category: "invoice",
    description: "Contemporary invoice design with accent colors",
    thumbnail: null,
    content: {
      companyName: "Modern Business Co.",
      companyAddress: "789 Innovation Drive, Tech City, TC 11111",
      companyEmail: "billing@modern.co",
      companyPhone: "+1 (555) 987-6543",
      clientName: "Valued Client",
      clientAddress: "321 Customer Lane, Client City, CC 22222",
      invoiceNumber: "INV-2024-001",
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Consulting Services", quantity: 10, rate: 150, amount: 1500 }
      ],
      subtotal: 1500,
      tax: 150,
      total: 1650,
      notes: "Payment due within 15 days"
    }
  },
  {
    name: "Minimal Invoice",
    category: "invoice",
    description: "Ultra-clean minimal invoice design",
    thumbnail: null,
    content: {
      companyName: "Minimal Design Studio",
      companyAddress: "",
      companyEmail: "hello@minimal.design",
      companyPhone: "",
      clientName: "Client",
      clientAddress: "",
      invoiceNumber: "001",
      invoiceDate: new Date().toISOString().split('T')[0],
      items: [
        { description: "Design Services", quantity: 1, rate: 2500, amount: 2500 }
      ],
      subtotal: 2500,
      total: 2500
    }
  },
  {
    name: "Detailed Invoice",
    category: "invoice",
    description: "Comprehensive invoice with all details",
    thumbnail: null,
    content: {
      companyName: "Enterprise Solutions Inc.",
      companyAddress: "100 Corporate Blvd, Suite 500, Business City, BC 33333",
      companyEmail: "accounts@enterprise.com",
      companyPhone: "+1 (555) 111-2222",
      clientName: "ABC Corporation",
      clientAddress: "200 Client Street, Client City, CC 44444",
      invoiceNumber: "ES-2024-0001",
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Software License (Annual)", quantity: 10, rate: 500, amount: 5000 },
        { description: "Implementation Services", quantity: 40, rate: 200, amount: 8000 },
        { description: "Training & Support", quantity: 1, rate: 2000, amount: 2000 }
      ],
      subtotal: 15000,
      tax: 1500,
      total: 16500,
      notes: "Net 45 days. Late payment subject to 1.5% monthly interest charge."
    }
  },
  {
    name: "Freelance Invoice",
    category: "invoice",
    description: "Perfect for freelancers and contractors",
    thumbnail: null,
    content: {
      companyName: "John Doe - Freelance Developer",
      companyAddress: "Remote",
      companyEmail: "john@freelance.dev",
      companyPhone: "+1 (555) 999-8888",
      clientName: "Startup Inc.",
      clientAddress: "Tech Hub, Innovation City",
      invoiceNumber: "JD-2024-01",
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Web Development (40 hours)", quantity: 40, rate: 100, amount: 4000 }
      ],
      subtotal: 4000,
      total: 4000,
      notes: "Payment via bank transfer or PayPal"
    }
  },

  // LETTER TEMPLATES (5)
  {
    name: "Business Letter",
    category: "letter",
    description: "Formal business correspondence template",
    thumbnail: null,
    content: {
      senderName: "Your Name",
      senderAddress: "123 Business Street\nCity, State 12345",
      recipientName: "Recipient Name",
      recipientAddress: "456 Recipient Ave\nCity, State 67890",
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      subject: "Business Proposal",
      salutation: "Dear Recipient Name,",
      body: "I am writing to discuss an exciting business opportunity that I believe would be of great interest to you.\n\nOur company has developed innovative solutions that could benefit your organization significantly. I would appreciate the opportunity to discuss this further at your convenience.\n\nThank you for your time and consideration.",
      closing: "Sincerely,",
      signature: "Your Name"
    }
  },
  {
    name: "Cover Letter",
    category: "letter",
    description: "Professional job application cover letter",
    thumbnail: null,
    content: {
      senderName: "Your Name",
      senderAddress: "789 Professional Lane\nCity, State 11111",
      recipientName: "Hiring Manager",
      recipientAddress: "Company Name\n123 Corporate Blvd\nCity, State 22222",
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      subject: "Application for [Position Title]",
      salutation: "Dear Hiring Manager,",
      body: "I am excited to apply for the [Position Title] position at [Company Name]. With my background in [your field] and proven track record of success, I am confident I would be a valuable addition to your team.\n\nMy experience includes [key achievements and skills]. I am particularly drawn to this opportunity because [specific reasons related to the company].\n\nI would welcome the opportunity to discuss how my skills and experiences align with your needs.",
      closing: "Best regards,",
      signature: "Your Name"
    }
  },
  {
    name: "Recommendation Letter",
    category: "letter",
    description: "Letter of recommendation template",
    thumbnail: null,
    content: {
      senderName: "Recommender Name",
      senderAddress: "Organization Name\n123 Reference Street\nCity, State 33333",
      recipientName: "To Whom It May Concern",
      recipientAddress: "",
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      subject: "Letter of Recommendation for [Candidate Name]",
      salutation: "To Whom It May Concern:",
      body: "I am pleased to recommend [Candidate Name] for [position/program]. I have had the pleasure of working with [him/her/them] for [duration] in my capacity as [your title].\n\n[Candidate Name] has consistently demonstrated [key qualities and achievements]. Their dedication, professionalism, and expertise make them an outstanding candidate.\n\nI strongly recommend [Candidate Name] and am confident they will excel in any endeavor they pursue.",
      closing: "Respectfully,",
      signature: "Recommender Name\nTitle"
    }
  },
  {
    name: "Thank You Letter",
    category: "letter",
    description: "Professional thank you letter",
    thumbnail: null,
    content: {
      senderName: "Your Name",
      senderAddress: "123 Gratitude Lane\nCity, State 44444",
      recipientName: "Recipient Name",
      recipientAddress: "456 Kindness Ave\nCity, State 55555",
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      salutation: "Dear Recipient Name,",
      body: "I wanted to take a moment to express my sincere gratitude for [specific reason].\n\nYour support and guidance have been invaluable, and I truly appreciate the time and effort you have invested. This opportunity has been incredibly meaningful to me.\n\nThank you once again for your generosity and kindness.",
      closing: "With appreciation,",
      signature: "Your Name"
    }
  },
  {
    name: "Formal Notice",
    category: "letter",
    description: "Formal notice or announcement letter",
    thumbnail: null,
    content: {
      senderName: "Organization Name",
      senderAddress: "Official Address\nCity, State 66666",
      recipientName: "Recipients",
      recipientAddress: "",
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      subject: "Important Notice",
      salutation: "Dear Recipients,",
      body: "This letter serves as formal notice regarding [subject matter].\n\nEffective [date], the following changes will take place: [details of changes or announcements].\n\nShould you have any questions or concerns, please do not hesitate to contact us.\n\nWe appreciate your attention to this matter.",
      closing: "Sincerely,",
      signature: "Organization Name\nAuthorized Signature"
    }
  },

  // QUOTATION TEMPLATES (5)
  {
    name: "Standard Quotation",
    category: "quotation",
    description: "Professional quotation template",
    thumbnail: null,
    content: {
      companyName: "Your Company Name",
      companyAddress: "123 Business Street, City, State 12345",
      companyEmail: "quotes@company.com",
      companyPhone: "+1 (555) 123-4567",
      clientName: "Prospective Client",
      clientAddress: "456 Client Avenue, City, State 67890",
      quotationNumber: "QUO-001",
      quotationDate: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Product/Service 1", quantity: 1, rate: 500, amount: 500 },
        { description: "Product/Service 2", quantity: 3, rate: 200, amount: 600 }
      ],
      subtotal: 1100,
      tax: 110,
      total: 1210,
      terms: "This quotation is valid for 30 days. Payment terms: 50% upfront, 50% upon completion."
    }
  },
  {
    name: "Detailed Quotation",
    category: "quotation",
    description: "Comprehensive quotation with breakdown",
    thumbnail: null,
    content: {
      companyName: "Premium Services Ltd.",
      companyAddress: "789 Enterprise Way, Business Park, BP 11111",
      companyEmail: "sales@premium.com",
      companyPhone: "+1 (555) 888-9999",
      clientName: "Corporate Client Inc.",
      clientAddress: "321 Corporate Drive, Suite 100, CC 22222",
      quotationNumber: "PS-Q-2024-001",
      quotationDate: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Initial Consultation & Planning", quantity: 1, rate: 1500, amount: 1500 },
        { description: "Implementation Phase 1", quantity: 1, rate: 5000, amount: 5000 },
        { description: "Implementation Phase 2", quantity: 1, rate: 5000, amount: 5000 },
        { description: "Training & Documentation", quantity: 1, rate: 2000, amount: 2000 },
        { description: "3 Months Support", quantity: 1, rate: 1500, amount: 1500 }
      ],
      subtotal: 15000,
      tax: 1500,
      total: 16500,
      terms: "Valid for 45 days. Payment: 30% deposit, 40% mid-project, 30% completion. Includes 90-day warranty."
    }
  },
  {
    name: "Service Quotation",
    category: "quotation",
    description: "Service-based quotation template",
    thumbnail: null,
    content: {
      companyName: "Expert Services Co.",
      companyAddress: "Remote Services",
      companyEmail: "hello@expertservices.com",
      companyPhone: "+1 (555) 777-6666",
      clientName: "Client Name",
      clientAddress: "",
      quotationNumber: "ESC-2024-Q001",
      quotationDate: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Consulting Hours (Block of 20)", quantity: 1, rate: 3000, amount: 3000 },
        { description: "Project Management", quantity: 1, rate: 1000, amount: 1000 }
      ],
      subtotal: 4000,
      total: 4000,
      terms: "Quote valid 21 days. Services billed monthly. Unused hours roll over for 60 days."
    }
  },
  {
    name: "Product Quotation",
    category: "quotation",
    description: "Product sales quotation",
    thumbnail: null,
    content: {
      companyName: "Quality Products Inc.",
      companyAddress: "100 Warehouse District, City, QP 33333",
      companyEmail: "orders@qualityproducts.com",
      companyPhone: "+1 (555) 444-3333",
      clientName: "Retail Partner",
      clientAddress: "500 Retail Plaza, City, RP 44444",
      quotationNumber: "QP-Q-001",
      quotationDate: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Product A (Bulk Order)", quantity: 100, rate: 50, amount: 5000 },
        { description: "Product B (Bulk Order)", quantity: 50, rate: 80, amount: 4000 },
        { description: "Shipping & Handling", quantity: 1, rate: 500, amount: 500 }
      ],
      subtotal: 9500,
      tax: 950,
      total: 10450,
      terms: "14-day quote validity. Bulk discount applied. Free shipping on orders over $10,000."
    }
  },
  {
    name: "Construction Quote",
    category: "quotation",
    description: "Construction/contractor quotation",
    thumbnail: null,
    content: {
      companyName: "BuildRight Contractors",
      companyAddress: "250 Construction Ave, City, BR 55555",
      companyEmail: "estimates@buildright.com",
      companyPhone: "+1 (555) 222-1111",
      clientName: "Property Owner",
      clientAddress: "789 Property Lane, City, PO 66666",
      quotationNumber: "BR-EST-2024-001",
      quotationDate: new Date().toISOString().split('T')[0],
      validUntil: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: [
        { description: "Demolition & Preparation", quantity: 1, rate: 5000, amount: 5000 },
        { description: "Materials & Supplies", quantity: 1, rate: 15000, amount: 15000 },
        { description: "Labor (estimated 200 hours)", quantity: 200, rate: 75, amount: 15000 },
        { description: "Equipment Rental", quantity: 1, rate: 3000, amount: 3000 },
        { description: "Permits & Inspections", quantity: 1, rate: 2000, amount: 2000 }
      ],
      subtotal: 40000,
      tax: 4000,
      total: 44000,
      terms: "Quote valid 60 days. Payment schedule: 25% deposit, 50% at mid-point, 25% completion. Includes 1-year warranty on workmanship."
    }
  }
];
