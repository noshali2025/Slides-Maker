import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { FileText, Upload, Download, Lock, Unlock } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { SEOHead } from "@/components/seo-head";
import type { CommunityTemplate } from "@shared/schema";

export default function Community() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: templates = [], isLoading } = useQuery<CommunityTemplate[]>({
    queryKey: ['/api/community-templates'],
  });

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Community Hub - Arriverr Slides | Share & Discover Templates"
        description="Explore and share presentation templates created by the Arriverr Slides community. Download, edit, and collaborate on professional designs."
        keywords="community templates, shared presentations, collaborative design, template sharing, user templates, presentation community"
      />
      
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2 hover-elevate rounded-md px-2 -ml-2" data-testid="link-home">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Arriverr Slides</span>
            </Link>
            <div className="flex items-center gap-4">
              <Link href="/templates">
                <Button variant="ghost" data-testid="link-templates">Templates</Button>
              </Link>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-12 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-4xl font-bold">Community Hub</h1>
              <p className="text-lg text-muted-foreground mt-2">
                Discover and share templates created by the community
              </p>
            </div>
            <Button className="gap-2" data-testid="button-upload">
              <Upload className="h-4 w-4" />
              Upload Template
            </Button>
          </div>
        </div>

        <div className="mb-8">
          <Input
            placeholder="Search community templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-md"
            data-testid="input-search"
          />
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading templates...</p>
          </div>
        ) : filteredTemplates.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-lg text-muted-foreground">
                {searchQuery ? "No templates found matching your search" : "No community templates yet"}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Be the first to share your creations with the community!
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="hover-elevate overflow-hidden" data-testid={`card-template-${template.id}`}>
                {template.thumbnail && (
                  <div className="aspect-video overflow-hidden bg-muted">
                    <img src={template.thumbnail} alt={template.name} className="w-full h-full object-cover" />
                  </div>
                )}
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="line-clamp-1">{template.name}</CardTitle>
                    {template.allowEditing === "true" ? (
                      <Unlock className="h-4 w-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <Lock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                  <CardDescription className="line-clamp-2">{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{template.category}</Badge>
                    <span className="text-sm text-muted-foreground">by {template.authorName}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                    <Download className="h-3 w-3" />
                    <span>{template.downloads} downloads</span>
                  </div>
                </CardContent>
                <CardFooter className="gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setLocation(`/editor/${template.id}`)}
                    data-testid={`button-use-${template.id}`}
                  >
                    Use Template
                  </Button>
                  {template.allowEditing === "true" && (
                    <Button
                      variant="secondary"
                      className="flex-1"
                      onClick={() => setLocation(`/editor/${template.id}`)}
                      data-testid={`button-edit-${template.id}`}
                    >
                      Edit & Remix
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
