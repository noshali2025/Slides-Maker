import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, FileSpreadsheet, Mail, FileCheck, Download, Sparkles, Zap, Shield, ArrowRight, Check, File, FileImage } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { SEOHead } from "@/components/seo-head";
import heroImage from "@assets/generated_images/Hero_platform_mockup_image_24963fc2.png";
import slideImage from "@assets/stock_images/modern_business_pres_1acd2060.jpg";
import invoiceImage from "@assets/stock_images/professional_invoice_a41375c2.jpg";
import letterImage from "@assets/stock_images/business_letter_form_79f70050.jpg";
import teamImage from "@assets/stock_images/people_collaborating_0b0e0588.jpg";

export default function Home() {
  const categories = [
    { icon: FileText, name: "Slides", count: "5+", color: "text-primary" },
    { icon: FileSpreadsheet, name: "Invoices", count: "5+", color: "text-chart-2" },
    { icon: Mail, name: "Letters", count: "5+", color: "text-chart-3" },
    { icon: FileCheck, name: "Quotations", count: "5+", color: "text-chart-4" },
  ];

  const features = [
    { icon: Sparkles, title: "20+ Templates", description: "Beautiful, professionally designed templates for every need" },
    { icon: Download, title: "Multi-Format Export", description: "Download as PDF, PPTX, DOCX, or JPG instantly" },
    { icon: Zap, title: "Real-time Preview", description: "See your changes as you edit in real-time" },
    { icon: Shield, title: "Easy Customization", description: "Intuitive editor for quick document creation" },
  ];

  const formats = [
    { name: "PDF", description: "Perfect for sharing and printing", icon: FileText },
    { name: "PPTX", description: "PowerPoint presentations", icon: File },
    { name: "DOCX", description: "Microsoft Word documents", icon: File },
    { name: "JPG", description: "High-quality images", icon: FileImage },
  ];

  const steps = [
    { number: "1", title: "Choose Template", description: "Browse 20+ professional templates across 4 categories" },
    { number: "2", title: "Customize", description: "Edit content, colors, and layout with our intuitive editor" },
    { number: "3", title: "Download", description: "Export to PDF, PPTX, DOCX, or JPG format instantly" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Arriverr Slides - Create Professional Presentations & Documents Online"
        description="Create stunning presentations and professional documents in minutes. Free online presentation maker with 20+ templates for slides, invoices, letters, and quotations. Export to PDF, PPTX, DOCX, and JPG."
        keywords="presentation maker, slide creator, free presentation tool, online slides, document generator, invoice maker, professional templates, presentation software, slide design, custom presentations, business documents, export to PDF, PPTX creator, PowerPoint alternative"
      />
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Arriverr Slides</span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/templates" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-templates">
                Templates
              </Link>
              <Link href="/templates" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-features">
                Features
              </Link>
            </nav>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Link href="/templates">
                <Button data-testid="button-get-started">Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-32">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="text-sm">
                  20+ Professional Templates
                </Badge>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
                  Create Professional Documents in{" "}
                  <span className="text-primary">Minutes</span>
                </h1>
                <p className="text-lg sm:text-xl text-muted-foreground">
                  Beautiful templates for slides, invoices, letters, and quotations. 
                  Export to PDF, PPTX, DOCX, or JPG with just one click.
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Link href="/templates">
                  <Button size="lg" className="gap-2" data-testid="button-hero-cta">
                    Start Creating <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/templates">
                  <Button size="lg" variant="outline" data-testid="button-browse-templates">
                    Browse Templates
                  </Button>
                </Link>
              </div>
              <div className="flex flex-wrap gap-8 pt-4">
                {categories.map((cat) => (
                  <div key={cat.name} className="flex items-center gap-2">
                    <cat.icon className={`h-5 w-5 ${cat.color}`} />
                    <div className="text-sm">
                      <span className="font-semibold">{cat.count}</span>
                      <span className="text-muted-foreground ml-1">{cat.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-accent/20 blur-3xl opacity-30" />
              <img
                src={heroImage}
                alt="Arriverr Slides Platform Interface"
                className="relative rounded-lg shadow-2xl"
                data-testid="img-hero"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Template Showcase */}
      <section className="py-24 bg-card/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold">Templates for Every Need</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Professional templates designed to help you create stunning documents in minutes
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="overflow-hidden hover-elevate" data-testid="card-showcase-slides">
              <div className="aspect-video overflow-hidden">
                <img src={slideImage} alt="Presentation Slides" className="w-full h-full object-cover" />
              </div>
              <CardHeader>
                <CardTitle>Presentation Slides</CardTitle>
                <CardDescription>Create stunning presentations that captivate your audience</CardDescription>
              </CardHeader>
            </Card>
            <Card className="overflow-hidden hover-elevate" data-testid="card-showcase-invoices">
              <div className="aspect-video overflow-hidden">
                <img src={invoiceImage} alt="Professional Invoices" className="w-full h-full object-cover" />
              </div>
              <CardHeader>
                <CardTitle>Professional Invoices</CardTitle>
                <CardDescription>Streamline your billing with beautiful invoice templates</CardDescription>
              </CardHeader>
            </Card>
            <Card className="overflow-hidden hover-elevate" data-testid="card-showcase-letters">
              <div className="aspect-video overflow-hidden">
                <img src={letterImage} alt="Business Letters" className="w-full h-full object-cover" />
              </div>
              <CardHeader>
                <CardTitle>Business Letters</CardTitle>
                <CardDescription>Professional correspondence made simple and elegant</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold">Everything You Need</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Powerful features designed to make document creation fast, easy, and professional
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <Card key={idx} className="hover-elevate" data-testid={`card-feature-${idx}`}>
                <CardHeader>
                  <feature.icon className="h-10 w-10 text-primary mb-4" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-card/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Create professional documents in three simple steps
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, idx) => (
              <div key={idx} className="relative" data-testid={`step-${idx}`}>
                {idx < steps.length - 1 && (
                  <div className="hidden md:block absolute top-16 left-full w-full h-0.5 bg-border -translate-x-1/2" />
                )}
                <div className="space-y-4">
                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground text-2xl font-bold">
                    {step.number}
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Export Formats */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold">Export to Any Format</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Download your documents in the format that works best for you
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {formats.map((format, idx) => (
              <Card key={idx} className="text-center hover-elevate" data-testid={`card-format-${idx}`}>
                <CardHeader>
                  <div className="mx-auto mb-4 h-12 w-12 flex items-center justify-center rounded-full bg-primary/10">
                    <format.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{format.name}</CardTitle>
                  <CardDescription>{format.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-3xl sm:text-5xl font-bold">
              Start Creating Beautiful Documents Today
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground">
              Join thousands of users creating professional documents with our templates
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/templates">
                <Button size="lg" className="gap-2" data-testid="button-cta-create">
                  Start Creating Now <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 justify-center pt-8">
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">No account required</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">Instant downloads</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">All formats supported</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-card/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <FileText className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">Arriverr Slides</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Professional document creation made simple and beautiful.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/templates" className="hover:text-foreground transition-colors">Templates</Link></li>
                <li><Link href="/community" className="hover:text-foreground transition-colors">Community Hub</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Categories</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/templates?category=slide" className="hover:text-foreground transition-colors">Slides</Link></li>
                <li><Link href="/templates?category=invoice" className="hover:text-foreground transition-colors">Invoices</Link></li>
                <li><Link href="/templates?category=letter" className="hover:text-foreground transition-colors">Letters</Link></li>
                <li><Link href="/templates?category=quotation" className="hover:text-foreground transition-colors">Quotations</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/terms" className="hover:text-foreground transition-colors">Terms of Service</Link></li>
                <li><Link href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link></li>
                <li><Link href="/guidelines" className="hover:text-foreground transition-colors">Guidelines</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Arriverr Slides. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
