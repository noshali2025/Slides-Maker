import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ArrowLeft, Heart, Users, Shield, MessageCircle } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { SEOHead } from "@/components/seo-head";

export default function Guidelines() {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Community Guidelines - Arriverr Slides"
        description="Learn about our community guidelines and standards for sharing content on Arriverr Slides. Create a positive and respectful environment."
        keywords="community guidelines, content policy, community standards, user guidelines, sharing policy"
      />
      
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2 hover-elevate rounded-md px-2 -ml-2" data-testid="link-home">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Arriverr Slides</span>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">Community Guidelines</h1>
          <p className="text-lg text-muted-foreground mb-12">Our guidelines help create a positive, creative, and respectful environment for everyone.</p>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <Card className="hover-elevate">
              <CardHeader>
                <Heart className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Be Respectful</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Treat all community members with respect and kindness. No harassment, hate speech, or discrimination of any kind.</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Share Thoughtfully</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Share high-quality, original content. Give credit where it's due and respect others' intellectual property.</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Stay Safe</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Don't share personal information. Report suspicious activity and help keep our community secure.</p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <MessageCircle className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Collaborate Positively</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Provide constructive feedback. Collaborate with others and help build a supportive creative community.</p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Content Standards</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>When sharing content in our Community Hub, please ensure:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Content is appropriate for all audiences</li>
                  <li>You have the right to share the content</li>
                  <li>Content doesn't contain malicious code or spam</li>
                  <li>Templates are functional and well-designed</li>
                  <li>Descriptions are accurate and helpful</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Prohibited Content</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>The following types of content are not allowed:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Illegal, harmful, or dangerous content</li>
                  <li>Spam, scams, or misleading content</li>
                  <li>Harassment, bullying, or threats</li>
                  <li>Hate speech or discrimination</li>
                  <li>Adult or sexually explicit content</li>
                  <li>Violence or graphic content</li>
                  <li>Copyright or trademark infringement</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sharing and Permissions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>When uploading templates to the Community Hub:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Choose whether to allow editing by others</li>
                  <li>Set appropriate permissions for your content</li>
                  <li>Respect the permissions set by other creators</li>
                  <li>Give credit when remixing others' work</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Reporting Violations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>If you see content that violates these guidelines:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Use the report button on the content</li>
                  <li>Provide specific details about the violation</li>
                  <li>Don't engage with the violator</li>
                  <li>Our team will review reports promptly</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Consequences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>Violations of these guidelines may result in:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Content removal</li>
                  <li>Temporary suspension</li>
                  <li>Permanent account termination</li>
                  <li>Legal action in serious cases</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
