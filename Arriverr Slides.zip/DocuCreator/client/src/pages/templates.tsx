import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { FileText, Search, Eye, ArrowRight } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { SEOHead } from "@/components/seo-head";
import type { Template } from "@shared/schema";

const categoryColors: Record<string, string> = {
  slide: "bg-primary/10 text-primary",
  invoice: "bg-chart-2/10 text-chart-2",
  letter: "bg-chart-3/10 text-chart-3",
  quotation: "bg-chart-4/10 text-chart-4",
};

const categoryLabels: Record<string, string> = {
  slide: "Slide",
  invoice: "Invoice",
  letter: "Letter",
  quotation: "Quotation",
};

export default function Templates() {
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: templates = [], isLoading } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });

  const categories = [
    { id: "all", label: "All Templates", count: templates.length },
    { id: "slide", label: "Slides", count: templates.filter(t => t.category === "slide").length },
    { id: "invoice", label: "Invoices", count: templates.filter(t => t.category === "invoice").length },
    { id: "letter", label: "Letters", count: templates.filter(t => t.category === "letter").length },
    { id: "quotation", label: "Quotations", count: templates.filter(t => t.category === "quotation").length },
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesCategory = selectedCategory === "all" || template.category === selectedCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Browse Templates - Arriverr Slides | Professional Presentation Templates"
        description="Explore 20+ professionally designed templates for presentations, invoices, letters, and quotations. Choose the perfect template for your needs and customize it instantly."
        keywords="presentation templates, slide templates, invoice templates, letter templates, quotation templates, business templates, professional designs, customizable templates, template gallery, presentation themes"
      />
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2 hover-elevate rounded-md px-2 -ml-2" data-testid="link-home">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Arriverr Slides</span>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="mb-12 space-y-4">
          <h1 className="text-4xl font-bold">Browse Templates</h1>
          <p className="text-lg text-muted-foreground">
            Choose from {templates.length} professionally designed templates
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat.id)}
                className="gap-2"
                data-testid={`button-category-${cat.id}`}
              >
                {cat.label}
                <Badge variant="secondary" className="ml-1">
                  {cat.count}
                </Badge>
              </Button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4 mb-2" />
                  <div className="h-4 bg-muted rounded w-full" />
                </CardHeader>
                <CardContent>
                  <div className="h-32 bg-muted rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredTemplates.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-lg text-muted-foreground" data-testid="text-empty-state">No templates found matching your criteria</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="group hover-elevate flex flex-col" data-testid={`card-template-${template.id}`}>
                <CardHeader className="flex-none">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <Badge className={categoryColors[template.category]} data-testid={`badge-category-${template.id}`}>
                      {categoryLabels[template.category]}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg" data-testid={`text-template-name-${template.id}`}>{template.name}</CardTitle>
                  <CardDescription className="line-clamp-2" data-testid={`text-template-desc-${template.id}`}>
                    {template.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="aspect-[4/3] rounded-md bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center border">
                    <FileText className="h-12 w-12 text-muted-foreground/40" />
                  </div>
                </CardContent>
                <CardFooter className="flex-none gap-2 flex-wrap">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-2"
                    data-testid={`button-preview-${template.id}`}
                  >
                    <Eye className="h-4 w-4" />
                    Preview
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 gap-2"
                    onClick={() => setLocation(`/editor/${template.id}`)}
                    data-testid={`button-use-${template.id}`}
                  >
                    Use Template <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
