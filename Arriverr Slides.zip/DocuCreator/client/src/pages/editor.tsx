import { useState, useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { FileText, Download, Home, Loader2, Plus, Trash2 } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { ExportDialog } from "@/components/export-dialog";
import { SlideRenderer, InvoiceRenderer, LetterRenderer, QuotationRenderer } from "@/components/document-renderers";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Template, Document as DocType } from "@shared/schema";

export default function Editor() {
  const { templateId } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [documentName, setDocumentName] = useState("My Document");
  const [documentData, setDocumentData] = useState<any>(null);

  const { data: template, isLoading: templateLoading } = useQuery<Template>({
    queryKey: ['/api/templates', templateId],
  });

  useEffect(() => {
    if (template?.content) {
      setDocumentData(template.content);
      setDocumentName(template.name);
    }
  }, [template]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/documents", {
        templateId: templateId!,
        name: documentName,
        content: documentData,
      }) as Promise<DocType>;
    },
    onSuccess: () => {
      toast({
        title: "Document Saved",
        description: "Your document has been saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "There was an error saving your document",
        variant: "destructive",
      });
    },
  });

  if (templateLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!template) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <p className="text-lg text-muted-foreground" data-testid="text-error">Template not found</p>
        <Link href="/templates">
          <Button data-testid="button-browse-templates-error">Browse Templates</Button>
        </Link>
      </div>
    );
  }

  const renderEditor = () => {
    switch (template.category) {
      case "slide":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={documentData?.title || ""}
                onChange={(e) => setDocumentData({ ...documentData, title: e.target.value })}
                data-testid="input-title"
              />
            </div>
            <div>
              <Label htmlFor="subtitle">Subtitle</Label>
              <Input
                id="subtitle"
                value={documentData?.subtitle || ""}
                onChange={(e) => setDocumentData({ ...documentData, subtitle: e.target.value })}
                data-testid="input-subtitle"
              />
            </div>
            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={documentData?.content || ""}
                onChange={(e) => setDocumentData({ ...documentData, content: e.target.value })}
                rows={4}
                data-testid="textarea-content"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="backgroundColor">Background Color</Label>
                <Input
                  id="backgroundColor"
                  type="color"
                  value={documentData?.backgroundColor || "#F8FAFC"}
                  onChange={(e) => setDocumentData({ ...documentData, backgroundColor: e.target.value })}
                  data-testid="input-bg-color"
                />
              </div>
              <div>
                <Label htmlFor="textColor">Text Color</Label>
                <Input
                  id="textColor"
                  type="color"
                  value={documentData?.textColor || "#1E293B"}
                  onChange={(e) => setDocumentData({ ...documentData, textColor: e.target.value })}
                  data-testid="input-text-color"
                />
              </div>
              <div>
                <Label htmlFor="accentColor">Accent Color</Label>
                <Input
                  id="accentColor"
                  type="color"
                  value={documentData?.accentColor || "#8B5CF6"}
                  onChange={(e) => setDocumentData({ ...documentData, accentColor: e.target.value })}
                  data-testid="input-accent-color"
                />
              </div>
            </div>
          </div>
        );

      case "invoice":
      case "quotation":
        const isInvoice = template.category === "invoice";
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Company Name</Label>
                <Input
                  value={documentData?.companyName || ""}
                  onChange={(e) => setDocumentData({ ...documentData, companyName: e.target.value })}
                  data-testid="input-company-name"
                />
              </div>
              <div>
                <Label>{isInvoice ? "Invoice" : "Quotation"} Number</Label>
                <Input
                  value={documentData?.[isInvoice ? "invoiceNumber" : "quotationNumber"] || ""}
                  onChange={(e) => setDocumentData({ ...documentData, [isInvoice ? "invoiceNumber" : "quotationNumber"]: e.target.value })}
                  data-testid="input-number"
                />
              </div>
            </div>
            <div>
              <Label>Client Name</Label>
              <Input
                value={documentData?.clientName || ""}
                onChange={(e) => setDocumentData({ ...documentData, clientName: e.target.value })}
                data-testid="input-client-name"
              />
            </div>
            <div>
              <Label>Items</Label>
              <div className="space-y-2">
                {documentData?.items?.map((item: any, idx: number) => (
                  <Card key={idx} className="p-4">
                    <div className="grid grid-cols-[1fr,auto,auto,auto,auto] gap-2 items-end">
                      <div>
                        <Label className="text-xs">Description</Label>
                        <Input
                          value={item.description}
                          onChange={(e) => {
                            const newItems = [...documentData.items];
                            newItems[idx].description = e.target.value;
                            setDocumentData({ ...documentData, items: newItems });
                          }}
                          data-testid={`input-item-desc-${idx}`}
                        />
                      </div>
                      <div className="w-20">
                        <Label className="text-xs">Qty</Label>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => {
                            const newItems = [...documentData.items];
                            newItems[idx].quantity = parseFloat(e.target.value);
                            newItems[idx].amount = newItems[idx].quantity * newItems[idx].rate;
                            const subtotal = newItems.reduce((sum, i) => sum + i.amount, 0);
                            setDocumentData({ ...documentData, items: newItems, subtotal, total: subtotal + (documentData.tax || 0) });
                          }}
                          data-testid={`input-item-qty-${idx}`}
                        />
                      </div>
                      <div className="w-24">
                        <Label className="text-xs">Rate</Label>
                        <Input
                          type="number"
                          value={item.rate}
                          onChange={(e) => {
                            const newItems = [...documentData.items];
                            newItems[idx].rate = parseFloat(e.target.value);
                            newItems[idx].amount = newItems[idx].quantity * newItems[idx].rate;
                            const subtotal = newItems.reduce((sum, i) => sum + i.amount, 0);
                            setDocumentData({ ...documentData, items: newItems, subtotal, total: subtotal + (documentData.tax || 0) });
                          }}
                          data-testid={`input-item-rate-${idx}`}
                        />
                      </div>
                      <div className="w-28">
                        <Label className="text-xs">Amount</Label>
                        <Input value={`$${item.amount.toFixed(2)}`} disabled />
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          const newItems = documentData.items.filter((_: any, i: number) => i !== idx);
                          const subtotal = newItems.reduce((sum: number, i: any) => sum + i.amount, 0);
                          setDocumentData({ ...documentData, items: newItems, subtotal, total: subtotal + (documentData.tax || 0) });
                        }}
                        data-testid={`button-delete-item-${idx}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newItem = { description: "", quantity: 1, rate: 0, amount: 0 };
                    setDocumentData({ ...documentData, items: [...(documentData?.items || []), newItem] });
                  }}
                  className="gap-2"
                  data-testid="button-add-item"
                >
                  <Plus className="h-4 w-4" />
                  Add Item
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="backgroundColor">Background Color</Label>
                <Input
                  id="backgroundColor"
                  type="color"
                  value={documentData?.backgroundColor || "#FFFFFF"}
                  onChange={(e) => setDocumentData({ ...documentData, backgroundColor: e.target.value })}
                  data-testid="input-bg-color"
                />
              </div>
              <div>
                <Label htmlFor="textColor">Text Color</Label>
                <Input
                  id="textColor"
                  type="color"
                  value={documentData?.textColor || "#1F2937"}
                  onChange={(e) => setDocumentData({ ...documentData, textColor: e.target.value })}
                  data-testid="input-text-color"
                />
              </div>
              <div>
                <Label htmlFor="accentColor">Accent Color</Label>
                <Input
                  id="accentColor"
                  type="color"
                  value={documentData?.accentColor || "#8B5CF6"}
                  onChange={(e) => setDocumentData({ ...documentData, accentColor: e.target.value })}
                  data-testid="input-accent-color"
                />
              </div>
            </div>
          </div>
        );

      case "letter":
        return (
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Sender Name</Label>
                <Input
                  value={documentData?.senderName || ""}
                  onChange={(e) => setDocumentData({ ...documentData, senderName: e.target.value })}
                  data-testid="input-sender-name"
                />
              </div>
              <div>
                <Label>Recipient Name</Label>
                <Input
                  value={documentData?.recipientName || ""}
                  onChange={(e) => setDocumentData({ ...documentData, recipientName: e.target.value })}
                  data-testid="input-recipient-name"
                />
              </div>
            </div>
            <div>
              <Label>Subject</Label>
              <Input
                value={documentData?.subject || ""}
                onChange={(e) => setDocumentData({ ...documentData, subject: e.target.value })}
                data-testid="input-subject"
              />
            </div>
            <div>
              <Label>Salutation</Label>
              <Input
                value={documentData?.salutation || ""}
                onChange={(e) => setDocumentData({ ...documentData, salutation: e.target.value })}
                data-testid="input-salutation"
              />
            </div>
            <div>
              <Label>Body</Label>
              <Textarea
                value={documentData?.body || ""}
                onChange={(e) => setDocumentData({ ...documentData, body: e.target.value })}
                rows={8}
                data-testid="textarea-body"
              />
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Closing</Label>
                <Input
                  value={documentData?.closing || ""}
                  onChange={(e) => setDocumentData({ ...documentData, closing: e.target.value })}
                  data-testid="input-closing"
                />
              </div>
              <div>
                <Label>Signature</Label>
                <Input
                  value={documentData?.signature || ""}
                  onChange={(e) => setDocumentData({ ...documentData, signature: e.target.value })}
                  data-testid="input-signature"
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="backgroundColor">Background Color</Label>
                <Input
                  id="backgroundColor"
                  type="color"
                  value={documentData?.backgroundColor || "#FFFFFF"}
                  onChange={(e) => setDocumentData({ ...documentData, backgroundColor: e.target.value })}
                  data-testid="input-bg-color"
                />
              </div>
              <div>
                <Label htmlFor="textColor">Text Color</Label>
                <Input
                  id="textColor"
                  type="color"
                  value={documentData?.textColor || "#1F2937"}
                  onChange={(e) => setDocumentData({ ...documentData, textColor: e.target.value })}
                  data-testid="input-text-color"
                />
              </div>
              <div>
                <Label htmlFor="accentColor">Accent Color</Label>
                <Input
                  id="accentColor"
                  type="color"
                  value={documentData?.accentColor || "#8B5CF6"}
                  onChange={(e) => setDocumentData({ ...documentData, accentColor: e.target.value })}
                  data-testid="input-accent-color"
                />
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const renderPreview = () => {
    if (!documentData) return null;

    switch (template.category) {
      case "slide":
        return <SlideRenderer data={documentData} />;
      case "invoice":
        return <InvoiceRenderer data={documentData} />;
      case "letter":
        return <LetterRenderer data={documentData} />;
      case "quotation":
        return <QuotationRenderer data={documentData} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 hover-elevate rounded-md px-2 -ml-2" data-testid="link-home">
                <Home className="h-5 w-5" />
              </Link>
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <Input
                  value={documentName}
                  onChange={(e) => setDocumentName(e.target.value)}
                  className="h-8 max-w-xs border-0 focus-visible:ring-0 font-medium"
                  data-testid="input-document-name"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button
                variant="outline"
                onClick={() => saveMutation.mutate()}
                disabled={saveMutation.isPending}
                data-testid="button-save"
              >
                {saveMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Save"
                )}
              </Button>
              <Button
                onClick={() => setShowExportDialog(true)}
                className="gap-2"
                data-testid="button-export"
              >
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-[400px,1fr] gap-8">
          {/* Editor Panel */}
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Edit Document</h2>
              <Card className="p-6">
                {renderEditor()}
              </Card>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Preview</h2>
            <div className="border rounded-lg bg-muted/20 p-8 overflow-auto">
              <div id="document-preview" className="mx-auto max-w-4xl">
                {renderPreview()}
              </div>
            </div>
          </div>
        </div>
      </div>

      <ExportDialog
        open={showExportDialog}
        onOpenChange={setShowExportDialog}
        elementId="document-preview"
        documentName={documentName}
        documentData={documentData}
      />
    </div>
  );
}
