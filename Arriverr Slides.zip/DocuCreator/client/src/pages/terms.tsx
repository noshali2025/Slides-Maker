import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ArrowLeft } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { SEOHead } from "@/components/seo-head";

export default function Terms() {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Terms of Service - Arriverr Slides"
        description="Read the terms of service for using Arriverr Slides platform. Understand your rights and responsibilities when creating presentations and documents."
        keywords="terms of service, user agreement, legal terms, Arriverr Slides terms, terms and conditions"
      />
      
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2 hover-elevate rounded-md px-2 -ml-2" data-testid="link-home">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Arriverr Slides</span>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">Terms of Service</h1>
          <p className="text-muted-foreground mb-12">Last updated: {new Date().toLocaleDateString()}</p>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>1. Acceptance of Terms</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>By accessing and using Arriverr Slides, you accept and agree to be bound by the terms and provision of this agreement.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>2. Use License</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>Permission is granted to temporarily download one copy of the materials on Arriverr Slides for personal, non-commercial transitory viewing only.</p>
                <p>This license shall automatically terminate if you violate any of these restrictions.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>3. User Content</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>You retain all rights to any content you submit, post or display on or through the service.</p>
                <p>By submitting content to our Community Hub, you grant us a non-exclusive, worldwide license to use, display, and distribute your content.</p>
                <p>You are responsible for the content you create and share through our platform.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>4. Prohibited Uses</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>You may not use Arriverr Slides:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>For any unlawful purpose or to solicit others to perform unlawful acts</li>
                  <li>To violate any international, federal, provincial or state regulations, rules, laws, or local ordinances</li>
                  <li>To infringe upon or violate our intellectual property rights or the intellectual property rights of others</li>
                  <li>To harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate</li>
                  <li>To upload or transmit viruses or any other type of malicious code</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>5. Intellectual Property</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>The service and its original content (excluding user-generated content), features, and functionality are owned by Arriverr Slides and are protected by international copyright, trademark, patent, trade secret, and other intellectual property laws.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>6. Termination</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>We may terminate or suspend access to our service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>7. Limitation of Liability</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>In no event shall Arriverr Slides, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>8. Changes to Terms</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>We reserve the right to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>9. Contact Us</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>If you have any questions about these Terms, please contact us through our support channels.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
