import type { SlideTemplate, InvoiceTemplate, LetterTemplate, QuotationTemplate } from "@shared/schema";

interface SlideRendererProps {
  data: SlideTemplate;
}

export function SlideRenderer({ data }: SlideRendererProps) {
  return (
    <div
      className="aspect-video w-full rounded-lg p-12 flex flex-col items-center justify-center text-center"
      style={{
        background: data.backgroundColor,
        color: data.textColor,
      }}
      data-testid="renderer-slide"
    >
      <h1 className="text-5xl font-bold mb-4" style={{ color: data.accentColor }}>
        {data.title}
      </h1>
      {data.subtitle && (
        <h2 className="text-2xl font-medium mb-6 opacity-90">
          {data.subtitle}
        </h2>
      )}
      <p className="text-lg max-w-3xl opacity-80">
        {data.content}
      </p>
    </div>
  );
}

interface InvoiceRendererProps {
  data: InvoiceTemplate;
}

export function InvoiceRenderer({ data }: InvoiceRendererProps) {
  return (
    <div 
      className="p-12 rounded-lg min-h-[842px]" 
      style={{
        backgroundColor: data.backgroundColor || "#FFFFFF",
        color: data.textColor || "#1F2937"
      }}
      data-testid="renderer-invoice">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-start mb-12">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{ color: data.accentColor || "#8B5CF6" }}>{data.companyName}</h1>
            {data.companyAddress && <p className="text-sm opacity-70 whitespace-pre-line">{data.companyAddress}</p>}
            {data.companyEmail && <p className="text-sm opacity-70">{data.companyEmail}</p>}
            {data.companyPhone && <p className="text-sm opacity-70">{data.companyPhone}</p>}
          </div>
          <div className="text-right">
            <h2 className="text-2xl font-bold mb-2">INVOICE</h2>
            <p className="text-sm"><span className="font-semibold">Invoice #:</span> {data.invoiceNumber}</p>
            <p className="text-sm"><span className="font-semibold">Date:</span> {data.invoiceDate}</p>
            {data.dueDate && <p className="text-sm"><span className="font-semibold">Due Date:</span> {data.dueDate}</p>}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-sm font-semibold mb-2" style={{ opacity: 0.6 }}>BILL TO:</h3>
          <p className="font-medium">{data.clientName}</p>
          {data.clientAddress && <p className="text-sm whitespace-pre-line" style={{ opacity: 0.7 }}>{data.clientAddress}</p>}
        </div>

        <table className="w-full mb-8">
          <thead style={{ backgroundColor: data.accentColor ? `${data.accentColor}20` : 'rgba(0,0,0,0.05)' }}>
            <tr>
              <th className="text-left py-3 px-4 font-semibold text-sm">Description</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Qty</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Rate</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {data.items.map((item, idx) => (
              <tr key={idx}>
                <td className="py-3 px-4">{item.description}</td>
                <td className="text-right py-3 px-4">{item.quantity}</td>
                <td className="text-right py-3 px-4">${item.rate.toFixed(2)}</td>
                <td className="text-right py-3 px-4">${item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-end mb-8">
          <div className="w-64">
            <div className="flex justify-between py-2">
              <span>Subtotal:</span>
              <span>${data.subtotal.toFixed(2)}</span>
            </div>
            {data.tax !== undefined && (
              <div className="flex justify-between py-2">
                <span>Tax:</span>
                <span>${data.tax.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between py-3 border-t-2 font-bold text-lg">
              <span>Total:</span>
              <span>${data.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {data.notes && (
          <div className="border-t pt-6">
            <p className="text-sm" style={{ opacity: 0.7 }}><span className="font-semibold">Notes:</span> {data.notes}</p>
          </div>
        )}
      </div>
    </div>
  );
}

interface LetterRendererProps {
  data: LetterTemplate;
}

export function LetterRenderer({ data }: LetterRendererProps) {
  return (
    <div 
      className="p-12 rounded-lg min-h-[842px]" 
      style={{
        backgroundColor: data.backgroundColor || "#FFFFFF",
        color: data.textColor || "#1F2937"
      }}
      data-testid="renderer-letter">
      <div className="max-w-3xl mx-auto space-y-6">
        {data.senderAddress && (
          <div className="text-sm whitespace-pre-line">
            {data.senderName && <p className="font-medium">{data.senderName}</p>}
            {data.senderAddress}
          </div>
        )}

        <div className="text-sm">
          <p>{data.date}</p>
        </div>

        {data.recipientAddress && (
          <div className="text-sm whitespace-pre-line">
            {data.recipientName && <p className="font-medium">{data.recipientName}</p>}
            {data.recipientAddress}
          </div>
        )}

        {data.subject && (
          <div className="font-semibold" style={{ color: data.accentColor || "#8B5CF6" }}>
            Re: {data.subject}
          </div>
        )}

        <div className="pt-4">
          <p className="mb-4">{data.salutation}</p>
          <div className="whitespace-pre-line leading-relaxed">
            {data.body}
          </div>
        </div>

        <div className="pt-6">
          <p className="mb-12">{data.closing}</p>
          <p className="font-medium">{data.signature}</p>
        </div>
      </div>
    </div>
  );
}

interface QuotationRendererProps {
  data: QuotationTemplate;
}

export function QuotationRenderer({ data }: QuotationRendererProps) {
  return (
    <div 
      className="p-12 rounded-lg min-h-[842px]" 
      style={{
        backgroundColor: data.backgroundColor || "#FFFFFF",
        color: data.textColor || "#1F2937"
      }}
      data-testid="renderer-quotation">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-start mb-12">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{ color: data.accentColor || "#8B5CF6" }}>{data.companyName}</h1>
            {data.companyAddress && <p className="text-sm opacity-70 whitespace-pre-line">{data.companyAddress}</p>}
            {data.companyEmail && <p className="text-sm opacity-70">{data.companyEmail}</p>}
            {data.companyPhone && <p className="text-sm opacity-70">{data.companyPhone}</p>}
          </div>
          <div className="text-right">
            <h2 className="text-2xl font-bold mb-2">QUOTATION</h2>
            <p className="text-sm"><span className="font-semibold">Quote #:</span> {data.quotationNumber}</p>
            <p className="text-sm"><span className="font-semibold">Date:</span> {data.quotationDate}</p>
            {data.validUntil && <p className="text-sm"><span className="font-semibold">Valid Until:</span> {data.validUntil}</p>}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-sm font-semibold mb-2" style={{ opacity: 0.6 }}>PREPARED FOR:</h3>
          <p className="font-medium">{data.clientName}</p>
          {data.clientAddress && <p className="text-sm whitespace-pre-line" style={{ opacity: 0.7 }}>{data.clientAddress}</p>}
        </div>

        <table className="w-full mb-8">
          <thead style={{ backgroundColor: data.accentColor ? `${data.accentColor}20` : 'rgba(0,0,0,0.05)' }}>
            <tr>
              <th className="text-left py-3 px-4 font-semibold text-sm">Description</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Qty</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Rate</th>
              <th className="text-right py-3 px-4 font-semibold text-sm">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {data.items.map((item, idx) => (
              <tr key={idx}>
                <td className="py-3 px-4">{item.description}</td>
                <td className="text-right py-3 px-4">{item.quantity}</td>
                <td className="text-right py-3 px-4">${item.rate.toFixed(2)}</td>
                <td className="text-right py-3 px-4">${item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-end mb-8">
          <div className="w-64">
            <div className="flex justify-between py-2">
              <span>Subtotal:</span>
              <span>${data.subtotal.toFixed(2)}</span>
            </div>
            {data.tax !== undefined && (
              <div className="flex justify-between py-2">
                <span>Tax:</span>
                <span>${data.tax.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between py-3 border-t-2 font-bold text-lg">
              <span>Total:</span>
              <span>${data.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {data.terms && (
          <div className="border-t pt-6">
            <p className="text-sm" style={{ opacity: 0.7 }}><span className="font-semibold">Terms & Conditions:</span> {data.terms}</p>
          </div>
        )}
      </div>
    </div>
  );
}
