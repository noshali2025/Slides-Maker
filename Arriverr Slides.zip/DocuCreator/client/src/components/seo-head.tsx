import { useEffect } from "react";

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  canonical?: string;
}

export function SEOHead({
  title = "Arriverr Slides - Professional Presentation & Document Creation Platform",
  description = "Create stunning presentations and professional documents in minutes with Arriverr Slides. Choose from 20+ beautiful templates for slides, invoices, letters, and quotations. Export to PDF, PPTX, DOCX, and JPG formats instantly.",
  keywords = "presentation maker, slide creator, document generator, invoice templates, professional slides, presentation templates, online presentation tool, slide design, custom presentations, business documents, export to PDF, PPTX creator, professional templates",
  ogImage = "",
  canonical = ""
}: SEOHeadProps) {
  useEffect(() => {
    document.title = title;

    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const attribute = property ? "property" : "name";
      let meta = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!meta) {
        meta = document.createElement("meta");
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      
      meta.setAttribute("content", content);
    };

    updateMetaTag("description", description);
    updateMetaTag("keywords", keywords);
    updateMetaTag("og:title", title, true);
    updateMetaTag("og:description", description, true);
    updateMetaTag("twitter:title", title, true);
    updateMetaTag("twitter:description", description, true);

    if (ogImage) {
      updateMetaTag("og:image", ogImage, true);
      updateMetaTag("twitter:image", ogImage, true);
    }

    if (canonical) {
      let link = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement("link");
        link.setAttribute("rel", "canonical");
        document.head.appendChild(link);
      }
      link.setAttribute("href", canonical);
    }
  }, [title, description, keywords, ogImage, canonical]);

  return null;
}
