import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, FileText, Loader2, File, FileImage } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import PptxGenJS from "pptxgenjs";
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from "docx";
import { saveAs } from "file-saver";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  elementId: string;
  documentName: string;
  documentData?: any;
}

export function ExportDialog({ open, onOpenChange, elementId, documentName, documentData }: ExportDialogProps) {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const exportFormats = [
    { id: "pdf", name: "PDF", icon: FileText, description: "Perfect for sharing and printing" },
    { id: "pptx", name: "PowerPoint", icon: File, description: "Editable presentation" },
    { id: "docx", name: "Word", icon: File, description: "Editable document" },
    { id: "jpg", name: "JPG", icon: FileImage, description: "High-quality image" },
  ];

  const exportToPDF = async () => {
    const element = document.getElementById(elementId);
    if (!element) return;

    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: "#ffffff",
      logging: false,
    });

    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({
      orientation: canvas.width > canvas.height ? "landscape" : "portrait",
      unit: "px",
      format: [canvas.width, canvas.height],
    });

    pdf.addImage(imgData, "PNG", 0, 0, canvas.width, canvas.height);
    pdf.save(`${documentName}.pdf`);
  };

  const exportToPPTX = async () => {
    const element = document.getElementById(elementId);
    if (!element) return;

    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: "#ffffff",
      logging: false,
    });

    const imgData = canvas.toDataURL("image/png");
    const pptx = new PptxGenJS();
    const slide = pptx.addSlide();
    
    slide.addImage({
      data: imgData,
      x: 0,
      y: 0,
      w: "100%",
      h: "100%",
    });

    await pptx.writeFile({ fileName: `${documentName}.pptx` });
  };

  const exportToDOCX = async () => {
    if (!documentData) {
      toast({
        title: "Export Error",
        description: "Document data not available for DOCX export",
        variant: "destructive",
      });
      return;
    }

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            text: documentData.title || documentData.companyName || documentData.senderName || "Document",
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({
            text: documentData.subtitle || documentData.subject || "",
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({ text: "" }),
          new Paragraph({
            text: JSON.stringify(documentData, null, 2),
          }),
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `${documentName}.docx`);
  };

  const exportToJPG = async () => {
    const element = document.getElementById(elementId);
    if (!element) return;

    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: "#ffffff",
      logging: false,
    });

    canvas.toBlob((blob) => {
      if (blob) {
        saveAs(blob, `${documentName}.jpg`);
      }
    }, "image/jpeg", 0.95);
  };

  const handleExport = async (format: string) => {
    setIsExporting(true);
    try {
      switch (format) {
        case "pdf":
          await exportToPDF();
          break;
        case "pptx":
          await exportToPPTX();
          break;
        case "docx":
          await exportToDOCX();
          break;
        case "jpg":
          await exportToJPG();
          break;
      }
      toast({
        title: "Export Successful",
        description: `Your document has been exported as ${format.toUpperCase()}`,
      });
      onOpenChange(false);
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting your document. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl" data-testid="dialog-export">
        <DialogHeader>
          <DialogTitle>Export Document</DialogTitle>
          <DialogDescription>
            Choose your preferred format to download your document
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          {exportFormats.map((format) => (
            <Card
              key={format.id}
              className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
              onClick={() => !isExporting && handleExport(format.id)}
              data-testid={`button-export-${format.id}`}
            >
              <div className="flex flex-col items-center text-center gap-3">
                <div className="h-12 w-12 flex items-center justify-center rounded-full bg-primary/10">
                  <format.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">{format.name}</h3>
                  <p className="text-sm text-muted-foreground">{format.description}</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full gap-2"
                  disabled={isExporting}
                  data-testid={`button-download-${format.id}`}
                >
                  {isExporting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4" />
                  )}
                  Download
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
