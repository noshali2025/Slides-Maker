import { pgTable, text, varchar, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const templates = pgTable("templates", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // 'slide', 'invoice', 'letter', 'quotation'
  description: text("description").notNull(),
  thumbnail: text("thumbnail"),
  content: jsonb("content").notNull(), // Template structure/fields
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey(),
  templateId: varchar("template_id").notNull(),
  name: text("name").notNull(),
  content: jsonb("content").notNull(), // User's customized data
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const communityTemplates = pgTable("community_templates", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  thumbnail: text("thumbnail"),
  content: jsonb("content").notNull(),
  authorName: text("author_name").notNull(),
  allowEditing: text("allow_editing").notNull().default("false"), // "true" or "false"
  downloads: text("downloads").notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

export const insertCommunityTemplateSchema = createInsertSchema(communityTemplates).omit({
  id: true,
  createdAt: true,
  downloads: true,
});

export type InsertCommunityTemplate = z.infer<typeof insertCommunityTemplateSchema>;
export type CommunityTemplate = typeof communityTemplates.$inferSelect;

// Template content schemas for different document types
export const slideTemplateSchema = z.object({
  title: z.string(),
  subtitle: z.string().optional(),
  content: z.string(),
  backgroundColor: z.string(),
  textColor: z.string(),
  accentColor: z.string(),
});

export const invoiceTemplateSchema = z.object({
  companyName: z.string(),
  companyAddress: z.string().optional(),
  companyEmail: z.string().optional(),
  companyPhone: z.string().optional(),
  clientName: z.string(),
  clientAddress: z.string().optional(),
  invoiceNumber: z.string(),
  invoiceDate: z.string(),
  dueDate: z.string().optional(),
  items: z.array(z.object({
    description: z.string(),
    quantity: z.number(),
    rate: z.number(),
    amount: z.number(),
  })),
  subtotal: z.number(),
  tax: z.number().optional(),
  total: z.number(),
  notes: z.string().optional(),
  backgroundColor: z.string().optional(),
  textColor: z.string().optional(),
  accentColor: z.string().optional(),
});

export const letterTemplateSchema = z.object({
  senderName: z.string(),
  senderAddress: z.string().optional(),
  recipientName: z.string(),
  recipientAddress: z.string().optional(),
  date: z.string(),
  subject: z.string().optional(),
  salutation: z.string(),
  body: z.string(),
  closing: z.string(),
  signature: z.string(),
  backgroundColor: z.string().optional(),
  textColor: z.string().optional(),
  accentColor: z.string().optional(),
});

export const quotationTemplateSchema = z.object({
  companyName: z.string(),
  companyAddress: z.string().optional(),
  companyEmail: z.string().optional(),
  companyPhone: z.string().optional(),
  clientName: z.string(),
  clientAddress: z.string().optional(),
  quotationNumber: z.string(),
  quotationDate: z.string(),
  validUntil: z.string().optional(),
  items: z.array(z.object({
    description: z.string(),
    quantity: z.number(),
    rate: z.number(),
    amount: z.number(),
  })),
  subtotal: z.number(),
  tax: z.number().optional(),
  total: z.number(),
  terms: z.string().optional(),
  backgroundColor: z.string().optional(),
  textColor: z.string().optional(),
  accentColor: z.string().optional(),
});

export type SlideTemplate = z.infer<typeof slideTemplateSchema>;
export type InvoiceTemplate = z.infer<typeof invoiceTemplateSchema>;
export type LetterTemplate = z.infer<typeof letterTemplateSchema>;
export type QuotationTemplate = z.infer<typeof quotationTemplateSchema>;
