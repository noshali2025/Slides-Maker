import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTemplateSchema, insertDocumentSchema, insertCommunityTemplateSchema } from "@shared/schema";
import { TEMPLATE_DATA } from "../client/src/lib/templates";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize templates on startup
  const initializeTemplates = async () => {
    const existingTemplates = await storage.getAllTemplates();
    if (existingTemplates.length === 0) {
      for (const templateData of TEMPLATE_DATA) {
        await storage.createTemplate(templateData as any);
      }
    }
  };

  await initializeTemplates();

  // Template routes
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.get("/api/templates/:id", async (req, res) => {
    try {
      const template = await storage.getTemplate(req.params.id);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      console.error("Error fetching template:", error);
      res.status(500).json({ error: "Failed to fetch template" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const validatedData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      console.error("Error creating template:", error);
      res.status(400).json({ error: "Invalid template data" });
    }
  });

  // Document routes
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  app.get("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  app.post("/api/documents", async (req, res) => {
    try {
      const validatedData = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(validatedData);
      res.status(201).json(document);
    } catch (error) {
      console.error("Error creating document:", error);
      res.status(400).json({ error: "Invalid document data" });
    }
  });

  app.patch("/api/documents/:id", async (req, res) => {
    try {
      const validatedData = insertDocumentSchema.partial().parse(req.body);
      const document = await storage.updateDocument(req.params.id, validatedData);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      console.error("Error updating document:", error);
      res.status(400).json({ error: "Failed to update document" });
    }
  });

  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteDocument(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Community Template routes
  app.get("/api/community-templates", async (req, res) => {
    try {
      const templates = await storage.getAllCommunityTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching community templates:", error);
      res.status(500).json({ error: "Failed to fetch community templates" });
    }
  });

  app.get("/api/community-templates/:id", async (req, res) => {
    try {
      const template = await storage.getCommunityTemplate(req.params.id);
      if (!template) {
        return res.status(404).json({ error: "Community template not found" });
      }
      res.json(template);
    } catch (error) {
      console.error("Error fetching community template:", error);
      res.status(500).json({ error: "Failed to fetch community template" });
    }
  });

  app.post("/api/community-templates", async (req, res) => {
    try {
      const validatedData = insertCommunityTemplateSchema.parse(req.body);
      const template = await storage.createCommunityTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      console.error("Error creating community template:", error);
      res.status(400).json({ error: "Invalid community template data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
