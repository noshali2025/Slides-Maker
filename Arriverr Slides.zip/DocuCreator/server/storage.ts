import { type Template, type InsertTemplate, type Document, type InsertDocument, type CommunityTemplate, type InsertCommunityTemplate } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Templates
  getAllTemplates(): Promise<Template[]>;
  getTemplate(id: string): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;

  // Documents
  getAllDocuments(): Promise<Document[]>;
  getDocument(id: string): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<boolean>;

  // Community Templates
  getAllCommunityTemplates(): Promise<CommunityTemplate[]>;
  getCommunityTemplate(id: string): Promise<CommunityTemplate | undefined>;
  createCommunityTemplate(template: InsertCommunityTemplate): Promise<CommunityTemplate>;
}

export class MemStorage implements IStorage {
  private templates: Map<string, Template>;
  private documents: Map<string, Document>;
  private communityTemplates: Map<string, CommunityTemplate>;

  constructor() {
    this.templates = new Map();
    this.documents = new Map();
    this.communityTemplates = new Map();
  }

  // Templates
  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values());
  }

  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const template: Template = {
      ...insertTemplate,
      thumbnail: insertTemplate.thumbnail ?? null,
      id,
      createdAt: new Date(),
    };
    this.templates.set(id, template);
    return template;
  }

  // Documents
  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const now = new Date();
    const document: Document = {
      ...insertDocument,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: string, updates: Partial<InsertDocument>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;

    const updated: Document = {
      ...document,
      ...updates,
      updatedAt: new Date(),
    };
    this.documents.set(id, updated);
    return updated;
  }

  async deleteDocument(id: string): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Community Templates
  async getAllCommunityTemplates(): Promise<CommunityTemplate[]> {
    return Array.from(this.communityTemplates.values());
  }

  async getCommunityTemplate(id: string): Promise<CommunityTemplate | undefined> {
    return this.communityTemplates.get(id);
  }

  async createCommunityTemplate(insertTemplate: InsertCommunityTemplate): Promise<CommunityTemplate> {
    const id = randomUUID();
    const template: CommunityTemplate = {
      ...insertTemplate,
      thumbnail: insertTemplate.thumbnail ?? null,
      allowEditing: insertTemplate.allowEditing ?? "false",
      id,
      downloads: "0",
      createdAt: new Date(),
    };
    this.communityTemplates.set(id, template);
    return template;
  }
}

export const storage = new MemStorage();
