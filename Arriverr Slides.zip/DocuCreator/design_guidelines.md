# Design Guidelines: Professional Document Creation Platform

## Design Approach

**Selected Approach**: Reference-Based (inspired by Canva, Figma, Adobe Express, Notion)

**Rationale**: This is a creative productivity tool where visual appeal and intuitive interaction drive user engagement. The platform showcases diverse templates while providing a powerful editing experience.

**Key Principles**:
- Visual-first template showcase with instant preview
- Clean, distraction-free editor interface
- Professional design that builds user trust
- Seamless flow from browsing → editing → exporting

---

## Core Design Elements

### A. Color Palette

**Light Mode (Primary)**:
- Primary Brand: 250 70% 50% (vibrant purple-blue)
- Primary Hover: 250 70% 45%
- Secondary: 210 100% 96% (soft blue background)
- Accent: 340 82% 52% (coral pink for CTAs)
- Success: 142 71% 45%
- Text Primary: 222 47% 11%
- Text Secondary: 215 16% 47%
- Background: 0 0% 100%
- Surface: 210 20% 98%

**Dark Mode**:
- Primary: 250 70% 60%
- Background: 222 47% 11%
- Surface: 217 33% 17%
- Text Primary: 210 40% 98%

### B. Typography

**Font Stack**:
- Display/Headings: 'Inter', -apple-system, sans-serif (700, 600, 500)
- Body: 'Inter', -apple-system, sans-serif (400, 500)
- Code/Monospace: 'JetBrains Mono', monospace

**Sizes**:
- Hero: 3.5rem (desktop), 2.5rem (mobile)
- H1: 2.5rem / H2: 2rem / H3: 1.5rem
- Body: 1rem / Small: 0.875rem

### C. Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24, 32
- Component padding: p-6, p-8
- Section spacing: py-16, py-20, py-24
- Element gaps: gap-4, gap-6, gap-8

**Grid System**:
- Template gallery: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Feature sections: grid-cols-1 lg:grid-cols-2
- Container: max-w-7xl for full-width, max-w-6xl for content

### D. Component Library

**Navigation**:
- Fixed header with backdrop blur (bg-white/80 dark:bg-gray-900/80)
- Logo + main nav + CTA button
- Mobile: hamburger menu with slide-in drawer

**Template Cards**:
- Elevated cards with subtle shadow and hover lift effect
- Thumbnail preview with category badge
- Quick actions: Preview, Use Template, Favorite
- Hover state: scale-105 transition with shadow-xl

**Editor Interface**:
- Left sidebar: Template/content controls (w-64)
- Center: Live canvas preview with zoom controls
- Right sidebar: Properties panel (w-80)
- Top toolbar: Export buttons, undo/redo, save

**Export Modal**:
- Large format selection cards (PDF, PPTX, DOCX, JPG)
- Custom settings panel (quality, size options)
- Download progress indicator

**CTA Buttons**:
- Primary: Full background with shadow-lg, hover:scale-105
- Secondary: Outline style with hover fill
- On images: backdrop-blur-md bg-white/20 border-white/40

### E. Page-Specific Designs

**Landing Page** (Hero + 6-8 sections):

1. **Hero Section** (h-screen, py-20):
   - Split layout: Left (60%) - headline + subtext + dual CTAs, Right (40%) - animated template showcase
   - Headline: "Create Professional Documents in Minutes"
   - Large hero image: Mockup of various templates on different devices
   - Gradient overlay: from-purple-600/10 to-pink-600/10

2. **Template Gallery Preview** (py-24):
   - Category tabs: All, Slides, Invoices, Letters, Quotations
   - Featured 8 templates in 4-column grid
   - "View All Templates" CTA

3. **Features Grid** (py-20):
   - 3-column layout with icons
   - Features: 20+ Templates, Multi-Format Export, Real-time Preview, Easy Customization, Professional Quality, Cloud Storage

4. **How It Works** (py-24):
   - 3-step process with large numbers and illustrations
   - Steps: Choose Template → Customize → Download

5. **Export Formats** (py-20):
   - 4-column grid showing PDF, PPTX, DOCX, JPG capabilities
   - File type icons with descriptions

6. **Testimonials** (py-24):
   - 3-column cards with user quotes and avatars
   - Subtle background pattern

7. **CTA Section** (py-32):
   - Centered with gradient background
   - "Start Creating Now" button

8. **Footer** (py-16):
   - 4-column layout: Product links, Resources, Company, Social
   - Newsletter signup form

**Template Browser Page**:
- Filter sidebar (left, w-72): Categories, colors, styles
- Main grid (3-4 columns)
- Search bar with live filtering
- Template hover reveals quick actions overlay

**Editor Page**:
- Full-screen canvas-centric layout
- Minimal chrome to maximize workspace
- Floating action buttons for common tasks
- Auto-save indicator in top-right

### Images Strategy

**Hero Section**: YES - Large hero image showing template mockups on laptop/tablet screens with subtle animation

**Additional Images**:
- Template thumbnails throughout
- Feature illustrations (custom graphics showing export process)
- How It Works section: Step-by-step visual guides
- Format showcase: High-quality icons representing file types

### Animations

**Minimal, purposeful only**:
- Template card hover: slight lift (transform scale-105)
- Page transitions: subtle fade
- Export progress: smooth loading bar
- NO scroll animations or excessive motion

---

## Accessibility & Polish

- All interactive elements have visible focus states (ring-2 ring-primary)
- Consistent dark mode across all inputs and modals
- High contrast ratios (WCAG AA minimum)
- Semantic HTML with proper ARIA labels
- Keyboard navigation fully supported
- Loading states for all async actions